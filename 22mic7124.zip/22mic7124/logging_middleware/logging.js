const axios = require("axios");

const Log = async (
    stack,
    level,
    packageName,
    message,
    token
) => {

    try {

        const response = await axios.post(
            "http://4.224.186.213/evaluation-service/logs",
            {
                stack: stack,
                level: level,
                package: packageName,
                message: message
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            }
        );

        console.log("Log created successfully");

        return response.data;

    } catch (error) {

        console.error(
            "Logging failed:",
            error.response?.data || error.message
        );

    }

};

module.exports = Log;