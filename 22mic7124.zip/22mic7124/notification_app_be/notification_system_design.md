# Stage 1

## Notification APIs

### Create Notification
POST /notifications

Request:
```json
{
  "studentid": 7124,
  "type": "Placement",
  "message": "Hiring drive"
}


Response:
```json
{
  "success": true
}


## Real-time Notification Design

Real-time notifications can be implemented using WebSockets or Server-Sent Events (SSE). This allows instant delivery of placement, event, and result notifications.



# Stage 2

## Database Choice

PostgreSQL was selected because:
- ACID compliance
- indexing support
- scalability
- efficient querying

## Schema

```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY,
    studentid INT,
    type VARCHAR(50),
    message TEXT,
    isread BOOLEAN DEFAULT false,
    createdat TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);




# Stage 3

## Query Optimization

Original query:

```sql
SELECT * FROM notifications
WHERE studentID = 1042
AND isRead = false
ORDER BY createdAt DESC;


Problems:
- SELECT *
- missing indexes
- full table scan

Optimized query:

```sql
SELECT id, type, message, createdat
FROM notifications
WHERE studentid = 1042
AND isread = false
ORDER BY createdat DESC;

Index used:

```sql
CREATE INDEX idx_notifications_student_read_created
ON notifications(studentid, isread, createdat DESC);




# Stage 4

## Performance Improvements

To reduce DB overload:
- pagination
- caching
- lazy loading
- WebSocket-based updates
- unread-only fetching



# Stage 5

## Notification Queue Design

Problems with sequential email sending:
- slow processing
- blocking operations
- poor scalability

Improved solution:
- asynchronous workers
- batch inserts
- queue systems like RabbitMQ/Kafka
- retry mechanisms


# Stage 6

## Priority Inbox

Priority score formula:

Priority = TypeWeight + RecencyScore

Weights:
- Placement → 15
- Result → 10
- Event → 5

Notifications are sorted by priority and top notifications are returned to users.