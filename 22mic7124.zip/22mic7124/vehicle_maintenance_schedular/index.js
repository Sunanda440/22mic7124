const express = require("express");
const axios = require("axios");
const cors = require("cors");

const optimizeTasks = require("./scheduler");
const Log = require("../logging_middleware/logger");
const app = express();

app.use(cors());
app.use(express.json());

const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiYXVkIjoiaHR0cDovLzIwLjI0NC41Ni4xNDQvZXZhbHVhdGlvbi1zZXJ2aWNlIiwiZW1haWwiOiJzdW5hbmRhLjIybWljNzEyNEB2aXRhcHN0dWRlbnQuYWMuaW4iLCJleHAiOjE3Nzg5MzIwMDQsImlhdCI6MTc3ODkzMTEwNCwiaXNzIjoiQWZmb3JkIE1lZGljYWwgVGVjaG5vbG9naWVzIFByaXZhdGUgTGltaXRlZCIsImp0aSI6ImFkNGNhOWM3LTVmY2QtNGFjNC04YTViLTNkNjdlN2Q3MGYzZSIsImxvY2FsZSI6ImVuLUlOIiwibmFtZSI6InRhbGxhbSBzdW5hbmRhIiwic3ViIjoiZGVkMWJjZDItOTA5Zi00YzQ0LTg2MmQtZWI1MTlkNWJjY2MzIn0sImVtYWlsIjoic3VuYW5kYS4yMm1pYzcxMjRAdml0YXBzdHVkZW50LmFjLmluIiwibmFtZSI6InRhbGxhbSBzdW5hbmRhIiwicm9sbE5vIjoiMjJtaWM3MTI0IiwiYWNjZXNzQ29kZSI6IlNmRnVXZyIsImNsaWVudElEIjoiZGVkMWJjZDItOTA5Zi00YzQ0LTg2MmQtZWI1MTlkNWJjY2MzIiwiY2xpZW50U2VjcmV0IjoiQXFiWnpuRG1GRGd2VXNoeSJ9.iYrCHtYbiWQaNbv_RTh633xQcY0z0fTtjuy_hW4NvzE";

app.get("/schedule", async (req, res) => {

    try {
        await Log(
            "backend",
            "info",
            "route",
            "Schedule endpoint accessed",
            token
        );

        const depotResponse = await axios.get(
            "http://4.224.186.213/evaluation-service/depots",
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        const vehicleResponse = await axios.get(
            "http://4.224.186.213/evaluation-service/vehicles",
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        await Log(
            "backend",
            "info",
            "service",
            "Fetched depot and vehicle data",
            token
        );

        const depots = depotResponse.data.depots;
        const vehicles = vehicleResponse.data.vehicles;

        const results = [];

        for (let depot of depots) {

            const maxImpact = optimizeTasks(
                vehicles,
                depot.MechanicHours
            );

            results.push({
                depotID: depot.ID,
                mechanicHours: depot.MechanicHours,
                maximumImpact: maxImpact
            });

        }

        await Log(
            "backend",
            "info",
            "controller",
            "Optimization completed successfully",
            token
        );

        res.status(200).json({
            success: true,
            data: results
        });

    } catch (error) {

        await Log(
            "backend",
            "error",
            "handler",
            "Scheduling process failed",
            token
        );

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

});

app.listen(5001, async () => {

    await Log(
        "backend",
        "info",
        "service",
        "Vehicle scheduler server started",
        token
    );

});